package com.code.beans;

import lombok.Data;

@Data
public class Project {
private  Integer pId;
private  String pName;
private  String pAddr;
private  Integer size;
}
