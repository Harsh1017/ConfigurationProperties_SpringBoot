package com.code.beans;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component("empp")
@ConfigurationProperties(prefix ="emp.details")
public class Employee {
private  Integer eId;
private String   eName;
private String   eAddrs;
//Array properties
private  String[] favColor;
//Collection  properties
private  List<String> nickName;
private  Set<Long> phoneNo;
private  Map<String,Long> idDetails;
//Has-a property
 private Project project;
@Override
public String toString() {
	return "Employee [eId=" + eId + ", eName=" + eName + ", eAddrs=" + eAddrs + ", favColor="
			+ Arrays.toString(favColor) + ", nickName=" + nickName + ", phoneNo=" + phoneNo + ", idDetails=" + idDetails
			+ ", project=" + project + "]";
}
 
}
