package com.code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.code.beans.Employee;

@SpringBootApplication
public class SpringBootPropertiesApplication {

	public static void main(String[] args) {
		//get Ioc  Conatiner
		ConfigurableApplicationContext container= SpringApplication.run(SpringBootPropertiesApplication.class, args);
	     Employee employee=container.getBean("empp",Employee.class);
	     System.out.println(employee);
	     container.close();
	 }

}
